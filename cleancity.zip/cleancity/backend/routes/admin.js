// routes/admin.js
// Only admin-role tokens reach these routes. Enforced server-side via requireRole,
// independent of whatever the frontend chooses to show/hide.

const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
const VALID_STATUSES = ['Pending', 'In Progress', 'Resolved'];

// GET /api/admin/reports  (admin only) - full queue with reporter name
router.get('/reports', requireAuth, requireRole('admin'), (req, res) => {
  const reports = db.prepare(`
    SELECT r.*, u.full_name AS reported_by, u.email AS reporter_email
    FROM reports r
    JOIN users u ON u.id = r.user_id
    ORDER BY r.created_at DESC
  `).all();

  const counts = db.prepare(`
    SELECT status, COUNT(*) AS c FROM reports GROUP BY status
  `).all();

  res.json({ reports, counts });
});

// PATCH /api/admin/reports/:id/status  (admin only)
router.patch('/reports/:id/status', requireAuth, requireRole('admin'), (req, res) => {
  const { status } = req.body;
  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ error: `status must be one of ${VALID_STATUSES.join(', ')}` });
  }

  const report = db.prepare('SELECT * FROM reports WHERE id = ?').get(req.params.id);
  if (!report) return res.status(404).json({ error: 'Report not found' });

  db.prepare('UPDATE reports SET status = ?, updated_at = datetime(\'now\') WHERE id = ?')
    .run(status, report.id);

  db.prepare(`INSERT INTO status_history (report_id, old_status, new_status, changed_by_user_id)
              VALUES (?, ?, ?, ?)`)
    .run(report.id, report.status, status, req.user.id);

  const updated = db.prepare('SELECT * FROM reports WHERE id = ?').get(report.id);
  res.json({ report: updated });
});

// GET /api/admin/reports/:id/history  (admin only) - audit trail
router.get('/reports/:id/history', requireAuth, requireRole('admin'), (req, res) => {
  const history = db.prepare(`
    SELECT h.*, u.full_name AS changed_by
    FROM status_history h JOIN users u ON u.id = h.changed_by_user_id
    WHERE h.report_id = ? ORDER BY h.changed_at ASC
  `).all(req.params.id);
  res.json({ history });
});

module.exports = router;
