// routes/reports.js
// Residents can create reports and view ONLY their own reports.
// File uploads are validated server-side (type + size) before storage.

const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const reportLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 15, // per account, per hour — prevents spam flooding of the queue
  keyGenerator: (req) => String(req.user?.id || req.ip),
  message: { error: 'Report submission limit reached. Please try again later.' }
});

const storage = multer.diskStorage({
  destination: path.join(__dirname, '..', 'uploads'),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${uuidv4()}${ext}`);
  }
});

function fileFilter(req, file, cb) {
  const allowed = ['image/jpeg', 'image/png'];
  if (!allowed.includes(file.mimetype)) {
    return cb(new Error('Only JPG or PNG images are allowed'));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 8 * 1024 * 1024 } // 8MB, matches the doc's upload note
});

function nextPublicId() {
  const year = new Date().getFullYear();
  const row = db.prepare("SELECT COUNT(*) AS c FROM reports WHERE public_id LIKE ?").get(`CLC-${year}-%`);
  const seq = (row.c + 1).toString().padStart(4, '0');
  return `CLC-${year}-${seq}`;
}

// POST /api/reports  (resident, auth required)
router.post('/', requireAuth, reportLimiter, upload.single('photo'), (req, res) => {
  const { location, description } = req.body;
  if (!location || !description) {
    return res.status(400).json({ error: 'location and description are required' });
  }

  const public_id = nextPublicId();
  const photo_path = req.file ? `/uploads/${req.file.filename}` : null;

  const info = db
    .prepare(`INSERT INTO reports (public_id, user_id, location, description, photo_path, status)
              VALUES (?, ?, ?, ?, ?, 'Pending')`)
    .run(public_id, req.user.id, location, description, photo_path);

  db.prepare(`INSERT INTO status_history (report_id, old_status, new_status, changed_by_user_id)
              VALUES (?, NULL, 'Pending', ?)`)
    .run(info.lastInsertRowid, req.user.id);

  const report = db.prepare('SELECT * FROM reports WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ report });
});

// GET /api/reports  (resident: only their own reports)
router.get('/', requireAuth, (req, res) => {
  const reports = db
    .prepare('SELECT * FROM reports WHERE user_id = ? ORDER BY created_at DESC')
    .all(req.user.id);
  res.json({ reports });
});

module.exports = router;
