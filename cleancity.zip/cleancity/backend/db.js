// db.js
// Uses SQLite (better-sqlite3) so the project runs with zero external setup.
// Schema mirrors the MySQL design in the project doc: users, reports, status_history.
// To move to MySQL: swap this file for a mysql2 pool and translate the CREATE TABLE
// statements below 1:1 (types map directly — INTEGER->INT, TEXT->VARCHAR/TEXT, etc).

const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'cleancity.db'));
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('resident','admin')) DEFAULT 'resident',
  ward TEXT DEFAULT 'Ward 14 - Gandhipuram',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  public_id TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  location TEXT NOT NULL,
  description TEXT NOT NULL,
  photo_path TEXT,
  status TEXT NOT NULL CHECK(status IN ('Pending','In Progress','Resolved')) DEFAULT 'Pending',
  ward TEXT DEFAULT 'Ward 14 - Gandhipuram',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS status_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  report_id INTEGER NOT NULL REFERENCES reports(id),
  old_status TEXT,
  new_status TEXT NOT NULL,
  changed_by_user_id INTEGER NOT NULL REFERENCES users(id),
  changed_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

module.exports = db;
