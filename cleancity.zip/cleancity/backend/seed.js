// seed.js — creates the sample accounts/reports described in the doc's
// "Sample Data Used for Testing" section. Run with: node seed.js
require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./db');

async function run() {
  const cost = parseInt(process.env.BCRYPT_COST || '12', 10);

  const adminEmail = 'meena.admin@cleancity.app';
  const residentEmail = 'ravi.kumar@gmail.com';

  if (!db.prepare('SELECT id FROM users WHERE email = ?').get(adminEmail)) {
    const hash = await bcrypt.hash('Admin@1234', cost);
    db.prepare('INSERT INTO users (full_name, email, password_hash, role) VALUES (?,?,?,?)')
      .run('S. Meena', adminEmail, hash, 'admin');
    console.log('Created admin:', adminEmail, '/ Admin@1234');
  }

  let resident = db.prepare('SELECT id FROM users WHERE email = ?').get(residentEmail);
  if (!resident) {
    const hash = await bcrypt.hash('Resident@1234', cost);
    const info = db.prepare('INSERT INTO users (full_name, email, password_hash, role) VALUES (?,?,?,?)')
      .run('Ravi Kumar', residentEmail, hash, 'resident');
    resident = { id: info.lastInsertRowid };
    console.log('Created resident:', residentEmail, '/ Resident@1234');
  }

  const admin = db.prepare('SELECT id FROM users WHERE email = ?').get(adminEmail);

  const samples = [
    { public_id: 'CLC-2026-0842', location: 'Gandhipuram Town Bus Stand, Coimbatore',
      description: 'Overflowing bin near the bus stand entrance for 3 days, waste spilling onto the walkway and attracting stray animals.',
      status: 'In Progress' },
    { public_id: 'CLC-2026-0799', location: 'RS Puram 4th Street, Coimbatore',
      description: 'Community bin damaged and lid missing — uncovered waste since the weekend, strong odor reported by residents.',
      status: 'Resolved' },
    { public_id: 'CLC-2026-0851', location: 'Peelamedu Market Road, Coimbatore',
      description: 'Construction debris dumped alongside household waste blocking half the road shoulder.',
      status: 'Pending' }
  ];

  for (const s of samples) {
    const exists = db.prepare('SELECT id FROM reports WHERE public_id = ?').get(s.public_id);
    if (exists) continue;
    const info = db.prepare(`INSERT INTO reports (public_id, user_id, location, description, status)
                              VALUES (?,?,?,?,?)`)
      .run(s.public_id, resident.id, s.location, s.description, s.status);
    db.prepare(`INSERT INTO status_history (report_id, old_status, new_status, changed_by_user_id)
                VALUES (?, NULL, 'Pending', ?)`).run(info.lastInsertRowid, resident.id);
    if (s.status !== 'Pending') {
      db.prepare(`INSERT INTO status_history (report_id, old_status, new_status, changed_by_user_id)
                  VALUES (?, 'Pending', ?, ?)`).run(info.lastInsertRowid, s.status, admin.id);
    }
    console.log('Seeded report', s.public_id);
  }

  console.log('Done.');
}

run();
